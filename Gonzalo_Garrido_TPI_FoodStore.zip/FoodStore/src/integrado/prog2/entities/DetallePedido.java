package integrado.prog2.entities;

public class DetallePedido extends Base {
    private int cantidad;
    private double subtotal;
    private Producto producto;  // Relación N:1

    public DetallePedido(int cantidad, double subtotal, Producto producto) {
        super();
        this.cantidad = cantidad;
        this.subtotal = subtotal;
        this.producto = producto;
    }

    public int getCantidad() { return cantidad; }
    public double getSubtotal() { return subtotal; }
    public Producto getProducto() { return producto; }

    public void setCantidad(int cantidad) { this.cantidad = cantidad; }
    public void setSubtotal(double subtotal) { this.subtotal = subtotal; }
    public void setProducto(Producto producto) { this.producto = producto; }

    @Override
    public String toString() {
        return String.format("  Detalle ID: %-4d | Producto: %-20s | Cantidad: %-4d | Subtotal: $%.2f",
                getId(),
                producto != null ? producto.getNombre() : "N/A",
                cantidad, subtotal);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof DetallePedido)) return false;
        DetallePedido other = (DetallePedido) obj;
        return this.getId().equals(other.getId());
    }
}
