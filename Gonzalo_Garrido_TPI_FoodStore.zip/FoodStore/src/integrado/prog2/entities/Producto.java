package integrado.prog2.entities;

public class Producto extends Base {
    private String nombre;
    private double precio;
    private String descripcion;
    private int stock;
    private String imagen;
    private boolean disponible;
    private Categoria categoria;  // Relación N:1

    public Producto(String nombre, double precio, String descripcion,
                    int stock, String imagen, boolean disponible, Categoria categoria) {
        super();
        this.nombre = nombre;
        this.precio = precio;
        this.descripcion = descripcion;
        this.stock = stock;
        this.imagen = imagen;
        this.disponible = disponible;
        this.categoria = categoria;
    }

    public String getNombre() { return nombre; }
    public double getPrecio() { return precio; }
    public String getDescripcion() { return descripcion; }
    public int getStock() { return stock; }
    public String getImagen() { return imagen; }
    public boolean isDisponible() { return disponible; }
    public Categoria getCategoria() { return categoria; }

    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setPrecio(double precio) { this.precio = precio; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public void setStock(int stock) { this.stock = stock; }
    public void setImagen(String imagen) { this.imagen = imagen; }
    public void setDisponible(boolean disponible) { this.disponible = disponible; }
    public void setCategoria(Categoria categoria) { this.categoria = categoria; }

    @Override
    public String toString() {
        return String.format("ID: %-4d | Nombre: %-20s | Precio: $%-8.2f | Stock: %-4d | Disponible: %-5s | Categoría: %s",
                getId(), nombre, precio, stock,
                disponible ? "Si" : "No",
                categoria != null ? categoria.getNombre() : "Sin categoría");
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Producto)) return false;
        Producto other = (Producto) obj;
        return this.getId().equals(other.getId());
    }
}
