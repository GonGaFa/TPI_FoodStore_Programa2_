package integrado.prog2.entities;

import java.time.LocalDateTime;

public abstract class Base {
    private Long id;
    private boolean eliminado;
    private LocalDateTime createdAt;

    // Contador estático para auto-incremento de IDs
    private static long contadorId = 1;

    public Base() {
        this.id = contadorId++;
        this.eliminado = false;
        this.createdAt = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public boolean isEliminado() { return eliminado; }
    public LocalDateTime getCreatedAt() { return createdAt; }

    public void setEliminado(boolean eliminado) { this.eliminado = eliminado; }

    // Resetador de contador
    public static void resetContador() { contadorId = 1; }
}
