package integrado.prog2.entities;

import integrado.prog2.enums.Rol;

public class Usuario extends Base {
    private String nombre;
    private String apellido;
    private String mail;
    private String celular;
    private String contrasenia;
    private Rol rol;

    public Usuario(String nombre, String apellido, String mail,
                   String celular, String contrasenia, Rol rol) {
        super();
        this.nombre = nombre;
        this.apellido = apellido;
        this.mail = mail;
        this.celular = celular;
        this.contrasenia = contrasenia;
        this.rol = rol;
    }

    public String getNombre() { return nombre; }
    public String getApellido() { return apellido; }
    public String getMail() { return mail; }
    public String getCelular() { return celular; }
    public String getContrasenia() { return contrasenia; }
    public Rol getRol() { return rol; }

    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setApellido(String apellido) { this.apellido = apellido; }
    public void setMail(String mail) { this.mail = mail; }
    public void setCelular(String celular) { this.celular = celular; }
    public void setContrasenia(String contrasenia) { this.contrasenia = contrasenia; }
    public void setRol(Rol rol) { this.rol = rol; }

    @Override
    public String toString() {
        return String.format("ID: %-4d | Nombre: %-10s | Apellido: %-15s | Mail: %-25s | Celular: %-12s | Rol: %s",
                getId(), nombre, apellido, mail, celular, rol);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Usuario)) return false;
        Usuario other = (Usuario) obj;
        return this.getId().equals(other.getId());
    }
}
