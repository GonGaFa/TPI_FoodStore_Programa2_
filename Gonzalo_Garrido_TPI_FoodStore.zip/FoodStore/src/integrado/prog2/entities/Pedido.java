package integrado.prog2.entities;

import integrado.prog2.enums.Estado;
import integrado.prog2.enums.FormaPago;
import integrado.prog2.exception.StockInvalidoException;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Pedido extends Base implements Calculable {
    private LocalDate fecha;
    private Estado estado;
    private double total;
    private FormaPago formaPago;
    private Usuario usuario;                    
    private List<DetallePedido> detalles;       

    public Pedido(Usuario usuario, FormaPago formaPago) {
        super();
        this.usuario = usuario;
        this.formaPago = formaPago;
        this.fecha = LocalDate.now();
        this.estado = Estado.PENDIENTE;
        this.total = 0.0;
        this.detalles = new ArrayList<>();
    }

    public LocalDate getFecha() { return fecha; }
    public Estado getEstado() { return estado; }
    public double getTotal() { return total; }
    public FormaPago getFormaPago() { return formaPago; }
    public Usuario getUsuario() { return usuario; }
    public List<DetallePedido> getDetalles() { return detalles; }

    public void setEstado(Estado estado) { this.estado = estado; }
    public void setFormaPago(FormaPago formaPago) { this.formaPago = formaPago; }

    /**
     * Agrega un detalle al pedido.
     * Lanza StockInvalidoException si cantidad <= 0 o no hay stock suficiente.
     */
    public void addDetallePedido(int cantidad, Double precioUnitario, Producto producto)
            throws StockInvalidoException {
        if (cantidad <= 0) {
            throw new StockInvalidoException("La cantidad debe ser mayor a 0.");
        }
        if (producto.getStock() < cantidad) {
            throw new StockInvalidoException("Stock insuficiente para '" + producto.getNombre()
                    + "'. Disponible: " + producto.getStock() + ", solicitado: " + cantidad);
        }
        double subtotal = cantidad * precioUnitario;
        DetallePedido detalle = new DetallePedido(cantidad, subtotal, producto);
        detalles.add(detalle);
    }

    /**
     * Busca un detalle por producto.
     */
    public DetallePedido findeDetallePedidoByProducto(Producto producto) {
        for (DetallePedido d : detalles) {
            if (!d.isEliminado() && d.getProducto().equals(producto)) {
                return d;
            }
        }
        return null;
    }

    /**
     * Elimina (lógicamente) el detalle correspondiente a un producto.
     */
    public void deleteDetallePedidoByProducto(Producto producto) {
        DetallePedido d = findeDetallePedidoByProducto(producto);
        if (d != null) {
            d.setEliminado(true);
        }
    }

    /**
     * Implementación de Calculable: recalcula el total sumando subtotales activos.
     */
    @Override
    public void calcularTotal() {
        double suma = 0.0;
        for (DetallePedido d : detalles) {
            if (!d.isEliminado()) {
                suma += d.getSubtotal();
            }
        }
        this.total = suma;
    }

    @Override
    public String toString() {
        String nombreUsuario = usuario != null
                ? usuario.getNombre() + " " + usuario.getApellido()
                : "Sin usuario";
        return String.format(
                "ID: %-4d | Usuario: %-20s | Estado: %-12s | Pago: %-14s | Total: $%-10.2f | Fecha: %s",
                getId(), nombreUsuario, estado, formaPago, total, fecha);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Pedido)) return false;
        Pedido other = (Pedido) obj;
        return this.getId().equals(other.getId());
    }
}
