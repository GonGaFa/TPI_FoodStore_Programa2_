package integrado.prog2.entities;

import java.util.ArrayList;
import java.util.List;

public class Categoria extends Base {
    private String nombre;
    private String descripcion;
    private List<Producto> productos;

    public Categoria(String nombre, String descripcion) {
        super();
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.productos = new ArrayList<>();
    }

    public String getNombre() { return nombre; }
    public String getDescripcion() { return descripcion; }
    public List<Producto> getProductos() { return productos; }

    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public void agregarProducto(Producto producto) {
        boolean nombreRepetido = productos.stream()
                .anyMatch(p -> p.getNombre().equalsIgnoreCase(producto.getNombre()));
        if (nombreRepetido) {
            throw new IllegalArgumentException(
                "Ya existe un producto con el nombre '" + producto.getNombre()
                + "' en la categoría '" + this.nombre + "'."
            );
        }
        this.productos.add(producto);
    }

    @Override
    public String toString() {
        return String.format("ID: %-4d | Nombre: %-20s | Descripción: %s",
                getId(), nombre, descripcion);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Categoria)) return false;
        Categoria other = (Categoria) obj;
        return this.getId().equals(other.getId());
    }
}