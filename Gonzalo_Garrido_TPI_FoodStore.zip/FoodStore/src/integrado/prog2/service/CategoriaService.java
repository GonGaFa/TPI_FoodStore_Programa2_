package integrado.prog2.service;

import integrado.prog2.entities.Categoria;
import integrado.prog2.entities.Producto;
import integrado.prog2.exception.EntidadNoEncontradaException;
import integrado.prog2.exception.ValidacionException;

import java.util.ArrayList;
import java.util.List;

public class CategoriaService {
    private final List<Categoria> categorias = new ArrayList<>();

    /**
     * Retorna solo categorías no eliminadas.
     */
    public List<Categoria> listar() {
        List<Categoria> activas = new ArrayList<>();
        for (Categoria c : categorias) {
            if (!c.isEliminado()) activas.add(c);
        }
        return activas;
    }

    /**
     * Crea una nueva categoría validando nombre no vacío y unicidad.
     */
    public Categoria crear(String nombre, String descripcion) throws ValidacionException {
        if (nombre == null || nombre.isBlank()) {
            throw new ValidacionException("El nombre de la categoría no puede estar vacío.");
        }
        if (descripcion == null || descripcion.isBlank()) {
            throw new ValidacionException("La descripción no puede estar vacía.");
        }
        for (Categoria c : categorias) {
            if (!c.isEliminado() && c.getNombre().equalsIgnoreCase(nombre.trim())) {
                throw new ValidacionException("Ya existe una categoría con el nombre '" + nombre + "'.");
            }
        }
        Categoria nueva = new Categoria(nombre.trim(), descripcion.trim());
        categorias.add(nueva);
        return nueva;
    }

    /**
     * Busca una categoría activa por ID.
     */
    public Categoria buscarPorId(Long id) throws EntidadNoEncontradaException {
        for (Categoria c : categorias) {
            if (c.getId().equals(id) && !c.isEliminado()) {
                return c;
            }
        }
        throw new EntidadNoEncontradaException("No se encontró categoría con ID: " + id);
    }

    /**
     * Edita nombre y/o descripción de una categoría.
     */
    public void editar(Long id, String nuevoNombre, String nuevaDescripcion)
            throws EntidadNoEncontradaException, ValidacionException {
        Categoria c = buscarPorId(id);

        if (nuevoNombre != null && !nuevoNombre.isBlank()) {
            // Verificar que no exista otra categoría con ese nombre
            for (Categoria other : categorias) {
                if (!other.getId().equals(id) && !other.isEliminado()
                        && other.getNombre().equalsIgnoreCase(nuevoNombre.trim())) {
                    throw new ValidacionException("Ya existe otra categoría con el nombre '"
                            + nuevoNombre + "'.");
                }
            }
            c.setNombre(nuevoNombre.trim());
        }
        if (nuevaDescripcion != null && !nuevaDescripcion.isBlank()) {
            c.setDescripcion(nuevaDescripcion.trim());
        }
    }

    /**
     * Baja lógica de categoría. Si tiene productos activos, impide la baja.
     */
    public void eliminar(Long id, List<Producto> todosLosProductos)
            throws EntidadNoEncontradaException, ValidacionException {
        Categoria c = buscarPorId(id);
        // Verificar si tiene productos activos asociados
        for (Producto p : todosLosProductos) {
            if (!p.isEliminado() && p.getCategoria() != null
                    && p.getCategoria().getId().equals(id)) {
                throw new ValidacionException(
                        "No se puede eliminar la categoría porque tiene productos activos asociados.");
            }
        }
        c.setEliminado(true);
    }
}
