package integrado.prog2.service;

import integrado.prog2.entities.DetallePedido;
import integrado.prog2.entities.Pedido;
import integrado.prog2.entities.Producto;
import integrado.prog2.entities.Usuario;
import integrado.prog2.enums.Estado;
import integrado.prog2.enums.FormaPago;
import integrado.prog2.exception.EntidadNoEncontradaException;
import integrado.prog2.exception.StockInvalidoException;
import integrado.prog2.exception.ValidacionException;

import java.util.ArrayList;
import java.util.List;

public class PedidoService {
    private final List<Pedido> pedidos = new ArrayList<>();

    /**
     * Retorna solo pedidos no eliminados.
     */
    public List<Pedido> listar() {
        List<Pedido> activos = new ArrayList<>();
        for (Pedido p : pedidos) {
            if (!p.isEliminado()) activos.add(p);
        }
        return activos;
    }

    /**
     * Retorna pedidos activos de un usuario específico.
     */
    public List<Pedido> listarPorUsuario(Usuario usuario) {
        List<Pedido> resultado = new ArrayList<>();
        for (Pedido p : pedidos) {
            if (!p.isEliminado() && p.getUsuario() != null
                    && p.getUsuario().getId().equals(usuario.getId())) {
                resultado.add(p);
            }
        }
        return resultado;
    }

    /**
     * Crea un pedido con sus detalles.
     * Si algún detalle falla, el pedido NO se agrega (consistencia).
     */
    public Pedido crear(Usuario usuario, FormaPago formaPago,
                        List<int[]> items, List<Producto> productosSeleccionados)
            throws ValidacionException, StockInvalidoException {
        if (usuario == null) {
            throw new ValidacionException("No se puede crear un pedido sin usuario.");
        }
        if (items.isEmpty()) {
            throw new ValidacionException("El pedido debe tener al menos un producto.");
        }

        Pedido nuevo = new Pedido(usuario, formaPago);

        // Intentar agregar todos los detalles; si falla alguno, no se guarda el pedido
        for (int i = 0; i < items.size(); i++) {
            int cantidad = items.get(i)[0];
            Producto producto = productosSeleccionados.get(i);
            // Puede lanzar StockInvalidoException → el pedido no se agrega
            nuevo.addDetallePedido(cantidad, producto.getPrecio(), producto);
        }

        // Calcular total usando la interfaz Calculable
        nuevo.calcularTotal();
        pedidos.add(nuevo);
        return nuevo;
    }

    /**
     * Busca un pedido activo por ID.
     */
    public Pedido buscarPorId(Long id) throws EntidadNoEncontradaException {
        for (Pedido p : pedidos) {
            if (p.getId().equals(id) && !p.isEliminado()) {
                return p;
            }
        }
        throw new EntidadNoEncontradaException("No se encontró pedido con ID: " + id);
    }

    /**
     * Actualiza estado y/o forma de pago de un pedido.
     */
    public void actualizarEstadoYPago(Long id, Estado nuevoEstado, FormaPago nuevaFormaPago)
            throws EntidadNoEncontradaException {
        Pedido p = buscarPorId(id);
        if (nuevoEstado != null) p.setEstado(nuevoEstado);
        if (nuevaFormaPago != null) p.setFormaPago(nuevaFormaPago);
    }

    /**
     * Baja lógica del pedido y de todos sus detalles.
     */
    public void eliminar(Long id) throws EntidadNoEncontradaException {
        Pedido p = buscarPorId(id);
        p.setEliminado(true);
        for (DetallePedido d : p.getDetalles()) {
            d.setEliminado(true);
        }
    }
}
