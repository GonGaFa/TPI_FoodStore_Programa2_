package integrado.prog2.service;

import integrado.prog2.entities.Usuario;
import integrado.prog2.enums.Rol;
import integrado.prog2.exception.EntidadNoEncontradaException;
import integrado.prog2.exception.ValidacionException;

import java.util.ArrayList;
import java.util.List;

public class UsuarioService {
    private final List<Usuario> usuarios = new ArrayList<>();

    /**
     * Retorna solo usuarios no eliminados.
     */
    public List<Usuario> listar() {
        List<Usuario> activos = new ArrayList<>();
        for (Usuario u : usuarios) {
            if (!u.isEliminado()) activos.add(u);
        }
        return activos;
    }

    /**
     * Crea un usuario validando campos y unicidad de mail.
     */
    public Usuario crear(String nombre, String apellido, String mail,
                         String celular, String contrasenia, Rol rol)
            throws ValidacionException {
        validarCamposObligatorios(nombre, apellido, mail);
        validarMailUnico(mail, null);
        Usuario nuevo = new Usuario(nombre.trim(), apellido.trim(), mail.trim(),
                celular.trim(), contrasenia, rol);
        usuarios.add(nuevo);
        return nuevo;
    }

    /**
     * Busca un usuario activo por ID.
     */
    public Usuario buscarPorId(Long id) throws EntidadNoEncontradaException {
        for (Usuario u : usuarios) {
            if (u.getId().equals(id) && !u.isEliminado()) {
                return u;
            }
        }
        throw new EntidadNoEncontradaException("No se encontró usuario con ID: " + id);
    }

    /**
     * Edita los datos de un usuario. Campos nulos/vacíos conservan el valor anterior.
     */
    public void editar(Long id, String nuevoNombre, String nuevoApellido,
                       String nuevoMail, String nuevoCelular, Rol nuevoRol)
            throws EntidadNoEncontradaException, ValidacionException {
        Usuario u = buscarPorId(id);

        if (nuevoNombre != null && !nuevoNombre.isBlank()) u.setNombre(nuevoNombre.trim());
        if (nuevoApellido != null && !nuevoApellido.isBlank()) u.setApellido(nuevoApellido.trim());
        if (nuevoMail != null && !nuevoMail.isBlank()) {
            validarMailUnico(nuevoMail.trim(), id);
            u.setMail(nuevoMail.trim());
        }
        if (nuevoCelular != null && !nuevoCelular.isBlank()) u.setCelular(nuevoCelular.trim());
        if (nuevoRol != null) u.setRol(nuevoRol);
    }

    /**
     * Baja lógica de usuario.
     */
    public void eliminar(Long id) throws EntidadNoEncontradaException {
        Usuario u = buscarPorId(id);
        u.setEliminado(true);
    }

    // ── Helpers privados ────────────────────────────────────────────────────

    private void validarCamposObligatorios(String nombre, String apellido, String mail)
            throws ValidacionException {
        if (nombre == null || nombre.isBlank())
            throw new ValidacionException("El nombre no puede estar vacío.");
        if (apellido == null || apellido.isBlank())
            throw new ValidacionException("El apellido no puede estar vacío.");
        if (mail == null || mail.isBlank())
            throw new ValidacionException("El mail no puede estar vacío.");
        if (!mail.contains("@"))
            throw new ValidacionException("El mail no tiene un formato válido.");
    }

    /**
     * Valida que no exista otro usuario activo con el mismo mail.
     * @param excluirId ID a ignorar (útil en edición); null para creación.
     */
    private void validarMailUnico(String mail, Long excluirId) throws ValidacionException {
        for (Usuario u : usuarios) {
            if (!u.isEliminado()
                    && u.getMail().equalsIgnoreCase(mail)
                    && (excluirId == null || !u.getId().equals(excluirId))) {
                throw new ValidacionException("Ya existe un usuario con el mail '" + mail + "'.");
            }
        }
    }
}
