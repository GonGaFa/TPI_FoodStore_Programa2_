package integrado.prog2.service;

import integrado.prog2.entities.Categoria;
import integrado.prog2.entities.Producto;
import integrado.prog2.exception.EntidadNoEncontradaException;
import integrado.prog2.exception.StockInvalidoException;
import integrado.prog2.exception.ValidacionException;

import java.util.ArrayList;
import java.util.List;

public class ProductoService {
    private final List<Producto> productos = new ArrayList<>();

    /**
     * Retorna todos los productos activos.
     */
    public List<Producto> listar() {
        List<Producto> activos = new ArrayList<>();
        for (Producto p : productos) {
            if (!p.isEliminado()) activos.add(p);
        }
        return activos;
    }

    /**
     * Retorna productos activos filtrados por categoría.
     */
    public List<Producto> listarPorCategoria(Categoria categoria) {
        List<Producto> resultado = new ArrayList<>();
        for (Producto p : productos) {
            if (!p.isEliminado() && p.getCategoria() != null
                    && p.getCategoria().getId().equals(categoria.getId())) {
                resultado.add(p);
            }
        }
        return resultado;
    }

    /**
     * Crea un producto con validaciones de negocio.
     */
    public Producto crear(String nombre, double precio, String descripcion, int stock,
                          String imagen, boolean disponible, Categoria categoria)
            throws ValidacionException, StockInvalidoException {
        if (nombre == null || nombre.isBlank()) {
            throw new ValidacionException("El nombre del producto no puede estar vacío.");
        }
        if (precio < 0) {
            throw new StockInvalidoException("El precio no puede ser negativo.");
        }
        if (stock < 0) {
            throw new StockInvalidoException("El stock no puede ser negativo.");
        }
        boolean nombreRepetido = productos.stream()
                .anyMatch(p -> !p.isEliminado() && p.getNombre().equalsIgnoreCase(nombre.trim()));
        if (nombreRepetido) {
            throw new ValidacionException("Ya existe un producto con el nombre '" + nombre.trim() + "'.");
        }
        Producto nuevo = new Producto(nombre.trim(), precio, descripcion, stock,
                imagen, disponible, categoria);
        productos.add(nuevo);
        return nuevo;
    }

    /**
     * Busca un producto activo por ID.
     */
    public Producto buscarPorId(Long id) throws EntidadNoEncontradaException {
        for (Producto p : productos) {
            if (p.getId().equals(id) && !p.isEliminado()) {
                return p;
            }
        }
        throw new EntidadNoEncontradaException("No se encontró producto con ID: " + id);
    }

    /**
     * Edita un producto. Campos nulos/vacíos conservan el valor anterior.
     */
    public void editar(Long id, String nuevoNombre, Double nuevoPrecio, String nuevaDesc,
                       Integer nuevoStock, String nuevaImagen, Boolean disponible, Categoria nuevaCategoria)
            throws EntidadNoEncontradaException, StockInvalidoException, ValidacionException {
        Producto p = buscarPorId(id);

        if (nuevoNombre != null && !nuevoNombre.isBlank()) {
            boolean nombreRepetido = productos.stream()
                    .anyMatch(o -> !o.isEliminado()
                            && !o.getId().equals(id)
                            && o.getNombre().equalsIgnoreCase(nuevoNombre.trim()));
            if (nombreRepetido) {
                throw new ValidacionException("Ya existe un producto con el nombre '" + nuevoNombre.trim() + "'.");
            }
            p.setNombre(nuevoNombre.trim());
        }
        if (nuevoPrecio != null) {
            if (nuevoPrecio < 0) throw new StockInvalidoException("El precio no puede ser negativo.");
            p.setPrecio(nuevoPrecio);
        }
        if (nuevaDesc != null && !nuevaDesc.isBlank()) p.setDescripcion(nuevaDesc.trim());
        if (nuevoStock != null) {
            if (nuevoStock < 0) throw new StockInvalidoException("El stock no puede ser negativo.");
            p.setStock(nuevoStock);
        }
        if (nuevaImagen != null && !nuevaImagen.isBlank()) p.setImagen(nuevaImagen.trim());
        if (disponible != null) p.setDisponible(disponible);
        if (nuevaCategoria != null) p.setCategoria(nuevaCategoria);
    }

    /**
     * Baja lógica de producto.
     */
    public void eliminar(Long id) throws EntidadNoEncontradaException {
        Producto p = buscarPorId(id);
        p.setEliminado(true);
    }

    /**
     * Expone la lista completa (incluye eliminados) para validaciones cruzadas.
     */
    public List<Producto> getTodos() {
        return productos;
    }
}
