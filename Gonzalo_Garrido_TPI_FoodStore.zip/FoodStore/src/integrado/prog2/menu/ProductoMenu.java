package integrado.prog2.menu;

import integrado.prog2.entities.Categoria;
import integrado.prog2.entities.Producto;
import integrado.prog2.service.CategoriaService;
import integrado.prog2.service.ProductoService;

import java.util.List;
import java.util.Scanner;

public class ProductoMenu {
    private final ProductoService productoService;
    private final CategoriaService categoriaService;
    private final Scanner sc;

    public ProductoMenu(ProductoService productoService,
                        CategoriaService categoriaService, Scanner sc) {
        this.productoService = productoService;
        this.categoriaService = categoriaService;
        this.sc = sc;
    }

    public void mostrar() {
        boolean volver = false;
        while (!volver) {
            System.out.println("\n" + MenuUtils.SEPARADOR);
            System.out.println("       GESTIÓN DE PRODUCTOS");
            System.out.println(MenuUtils.SEPARADOR);
            System.out.println("  1. Listar productos");
            System.out.println("  2. Listar por categoría");
            System.out.println("  3. Crear producto");
            System.out.println("  4. Editar producto");
            System.out.println("  5. Eliminar producto");
            System.out.println("  0. Volver al menú principal");
            System.out.println(MenuUtils.SEPARADOR_FINO);
            int opcion = MenuUtils.leerIntRango(sc, "  Seleccione: ", 0, 5);

            switch (opcion) {
                case 1 -> listar();
                case 2 -> listarPorCategoria();
                case 3 -> crear();
                case 4 -> editar();
                case 5 -> eliminar();
                case 0 -> volver = true;
            }
        }
    }

    private void listar() {
        System.out.println("\n--- LISTADO DE PRODUCTOS ---");
        List<Producto> lista = productoService.listar();
        if (lista.isEmpty()) {
            System.out.println("  No hay productos cargados.");
        } else {
            lista.forEach(p -> System.out.println("  " + p));
        }
        MenuUtils.pausar(sc);
    }

    private void listarPorCategoria() {
        System.out.println("\n--- LISTAR POR CATEGORÍA ---");
        listarCategoriasSilenciosas();
        try {
            Long idCat = MenuUtils.leerLong(sc, "  ID de la categoría: ");
            Categoria cat = categoriaService.buscarPorId(idCat);
            List<Producto> lista = productoService.listarPorCategoria(cat);
            System.out.println("  Productos de la categoría '" + cat.getNombre() + "':");
            if (lista.isEmpty()) {
                System.out.println("  No hay productos en esta categoría.");
            } else {
                lista.forEach(p -> System.out.println("  " + p));
            }
        } catch (Exception e) {
            MenuUtils.error(e.getMessage());
        }
        MenuUtils.pausar(sc);
    }

    private void crear() {
        System.out.println("\n--- CREAR PRODUCTO ---");
        listarCategoriasSilenciosas();
        try {
            // Verificar que haya categorías disponibles
            if (categoriaService.listar().isEmpty()) {
                MenuUtils.error("No hay categorías disponibles. Cree una categoría primero.");
                MenuUtils.pausar(sc);
                return;
            }
            Long idCat = MenuUtils.leerLong(sc, "  ID de categoría: ");
            Categoria cat = categoriaService.buscarPorId(idCat);

            String nombre = MenuUtils.leerTexto(sc, "  Nombre: ");
            String descripcion = MenuUtils.leerTexto(sc, "  Descripción: ");
            double precio = MenuUtils.leerDouble(sc, "  Precio: ");
            int stock = MenuUtils.leerInt(sc, "  Stock: ");
            String imagen = MenuUtils.leerTextoOpcional(sc, "  Imagen (URL o nombre, Enter para omitir): ");
            boolean disponible = MenuUtils.leerConfirmacion(sc, "  ¿Disponible?");

            Producto nuevo = productoService.crear(nombre, precio, descripcion,
                    stock, imagen.isBlank() ? "" : imagen, disponible, cat);
            MenuUtils.exito("Producto creado con ID: " + nuevo.getId());
        } catch (Exception e) {
            MenuUtils.error(e.getMessage());
        }
        MenuUtils.pausar(sc);
    }

    private void editar() {
        System.out.println("\n--- EDITAR PRODUCTO ---");
        listarSilenciosa();
        try {
            Long id = MenuUtils.leerLong(sc, "  ID del producto a editar: ");
            Producto p = productoService.buscarPorId(id);
            System.out.println("  Producto actual: " + p);
            System.out.println("  (Deje vacío para conservar el valor actual)");

            String nuevoNombre = MenuUtils.leerTextoOpcional(sc, "  Nuevo nombre: ");
            String strPrecio = MenuUtils.leerTextoOpcional(sc, "  Nuevo precio: ");
            String nuevaDesc = MenuUtils.leerTextoOpcional(sc, "  Nueva descripción: ");
            String strStock = MenuUtils.leerTextoOpcional(sc, "  Nuevo stock: ");
            String nuevaImagen = MenuUtils.leerTextoOpcional(sc, "  Nueva imagen: ");

            // Disponible
            Boolean disponible = null;
            String strDisp = MenuUtils.leerTextoOpcional(sc, "  ¿Disponible? (S/N o Enter para conservar): ");
            if (strDisp.equalsIgnoreCase("S")) disponible = true;
            else if (strDisp.equalsIgnoreCase("N")) disponible = false;

            // Categoría
            Categoria nuevaCat = null;
            String strCat = MenuUtils.leerTextoOpcional(sc, "  ID de nueva categoría (Enter para conservar): ");
            if (!strCat.isBlank()) {
                try {
                    nuevaCat = categoriaService.buscarPorId(Long.parseLong(strCat));
                } catch (Exception e) {
                    MenuUtils.error("Categoría no encontrada; se conserva la actual.");
                }
            }

            productoService.editar(id,
                    nuevoNombre.isBlank() ? null : nuevoNombre,
                    strPrecio.isBlank() ? null : Double.parseDouble(strPrecio.replace(",", ".")),
                    nuevaDesc.isBlank() ? null : nuevaDesc,
                    strStock.isBlank() ? null : Integer.parseInt(strStock),
                    nuevaImagen.isBlank() ? null : nuevaImagen,
                    disponible,
                    nuevaCat);
            MenuUtils.exito("Producto actualizado correctamente.");
        } catch (Exception e) {
            MenuUtils.error(e.getMessage());
        }
        MenuUtils.pausar(sc);
    }

    private void eliminar() {
        System.out.println("\n--- ELIMINAR PRODUCTO (baja lógica) ---");
        listarSilenciosa();
        try {
            Long id = MenuUtils.leerLong(sc, "  ID del producto a eliminar: ");
            Producto p = productoService.buscarPorId(id);
            System.out.println("  Producto: " + p);
            if (MenuUtils.leerConfirmacion(sc, "  ¿Confirma la eliminación?")) {
                productoService.eliminar(id);
                MenuUtils.exito("Producto eliminado (baja lógica).");
            } else {
                System.out.println("  Operación cancelada.");
            }
        } catch (Exception e) {
            MenuUtils.error(e.getMessage());
        }
        MenuUtils.pausar(sc);
    }

    private void listarSilenciosa() {
        List<Producto> lista = productoService.listar();
        if (!lista.isEmpty()) {
            System.out.println("  Productos disponibles:");
            lista.forEach(p -> System.out.println("    " + p));
        }
    }

    private void listarCategoriasSilenciosas() {
        List<Categoria> cats = categoriaService.listar();
        if (!cats.isEmpty()) {
            System.out.println("  Categorías disponibles:");
            cats.forEach(c -> System.out.println("    " + c));
        }
    }
}
