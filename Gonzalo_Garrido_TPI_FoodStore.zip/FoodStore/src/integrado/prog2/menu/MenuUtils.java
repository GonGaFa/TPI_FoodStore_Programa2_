package integrado.prog2.menu;

import java.util.Scanner;

/**
 * Utilidades reutilizables para la interacción con el usuario por consola.
 */
public class MenuUtils {

    private MenuUtils() {}

    public static final String SEPARADOR =
            "==================================================";
    public static final String SEPARADOR_FINO =
            "--------------------------------------------------";

    /** Lee una línea de texto no vacía; repite si el usuario no ingresa nada. */
    public static String leerTexto(Scanner sc, String prompt) {
        String valor;
        do {
            System.out.print(prompt);
            valor = sc.nextLine().trim();
            if (valor.isBlank()) {
                System.out.println("  [!] El campo no puede estar vacío. Intente de nuevo.");
            }
        } while (valor.isBlank());
        return valor;
    }

    /** Lee una línea de texto; permite vacío (Enter = sin cambio). */
    public static String leerTextoOpcional(Scanner sc, String prompt) {
        System.out.print(prompt);
        return sc.nextLine().trim();
    }

    /** Lee un Long; repite si la entrada no es un número válido. */
    public static Long leerLong(Scanner sc, String prompt) {
        while (true) {
            System.out.print(prompt);
            String entrada = sc.nextLine().trim();
            try {
                return Long.parseLong(entrada);
            } catch (NumberFormatException e) {
                System.out.println("  [!] Ingrese un número entero válido.");
            }
        }
    }

    /** Lee un int; repite si la entrada no es válida. */
    public static int leerInt(Scanner sc, String prompt) {
        while (true) {
            System.out.print(prompt);
            String entrada = sc.nextLine().trim();
            try {
                return Integer.parseInt(entrada);
            } catch (NumberFormatException e) {
                System.out.println("  [!] Ingrese un número entero válido.");
            }
        }
    }

    /** Lee un int dentro de un rango [min, max]; repite si está fuera de rango. */
    public static int leerIntRango(Scanner sc, String prompt, int min, int max) {
        while (true) {
            int valor = leerInt(sc, prompt);
            if (valor >= min && valor <= max) return valor;
            System.out.println("  [!] Opción fuera de rango. Ingrese entre " + min + " y " + max + ".");
        }
    }

    /** Lee un double; repite si la entrada no es válida. */
    public static double leerDouble(Scanner sc, String prompt) {
        while (true) {
            System.out.print(prompt);
            String entrada = sc.nextLine().trim().replace(",", ".");
            try {
                return Double.parseDouble(entrada);
            } catch (NumberFormatException e) {
                System.out.println("  [!] Ingrese un número decimal válido (ej: 150.50).");
            }
        }
    }

    /** Lee S/N del usuario; retorna true si es 'S'. */
    public static boolean leerConfirmacion(Scanner sc, String prompt) {
        while (true) {
            System.out.print(prompt + " (S/N): ");
            String entrada = sc.nextLine().trim().toUpperCase();
            if (entrada.equals("S")) return true;
            if (entrada.equals("N")) return false;
            System.out.println("  [!] Ingrese S o N.");
        }
    }

    /** Imprime un mensaje de éxito. */
    public static void exito(String mensaje) {
        System.out.println("  [OK] " + mensaje);
    }

    /** Imprime un mensaje de error. */
    public static void error(String mensaje) {
        System.out.println("  [ERROR] " + mensaje);
    }

    /** Pausa hasta que el usuario presione Enter. */
    public static void pausar(Scanner sc) {
        System.out.print("\n  Presione Enter para continuar...");
        sc.nextLine();
    }
}
