package integrado.prog2.menu;

import integrado.prog2.entities.Categoria;
import integrado.prog2.service.CategoriaService;
import integrado.prog2.service.ProductoService;

import java.util.List;
import java.util.Scanner;

public class CategoriaMenu {
    private final CategoriaService categoriaService;
    private final ProductoService productoService;
    private final Scanner sc;

    public CategoriaMenu(CategoriaService categoriaService,
                         ProductoService productoService, Scanner sc) {
        this.categoriaService = categoriaService;
        this.productoService = productoService;
        this.sc = sc;
    }

    public void mostrar() {
        boolean volver = false;
        while (!volver) {
            System.out.println("\n" + MenuUtils.SEPARADOR);
            System.out.println("       GESTIÓN DE CATEGORÍAS");
            System.out.println(MenuUtils.SEPARADOR);
            System.out.println("  1. Listar categorías");
            System.out.println("  2. Crear categoría");
            System.out.println("  3. Editar categoría");
            System.out.println("  4. Eliminar categoría");
            System.out.println("  0. Volver al menú principal");
            System.out.println(MenuUtils.SEPARADOR_FINO);
            int opcion = MenuUtils.leerIntRango(sc, "  Seleccione: ", 0, 4);

            switch (opcion) {
                case 1 -> listar();
                case 2 -> crear();
                case 3 -> editar();
                case 4 -> eliminar();
                case 0 -> volver = true;
            }
        }
    }

    private void listar() {
        System.out.println("\n--- LISTADO DE CATEGORÍAS ---");
        List<Categoria> lista = categoriaService.listar();
        if (lista.isEmpty()) {
            System.out.println("  No hay categorías cargadas.");
        } else {
            lista.forEach(c -> System.out.println("  " + c));
        }
        MenuUtils.pausar(sc);
    }

    private void crear() {
        System.out.println("\n--- CREAR CATEGORÍA ---");
        try {
            String nombre = MenuUtils.leerTexto(sc, "  Nombre: ");
            String descripcion = MenuUtils.leerTexto(sc, "  Descripción: ");
            Categoria nueva = categoriaService.crear(nombre, descripcion);
            MenuUtils.exito("Categoría creada con ID: " + nueva.getId());
        } catch (Exception e) {
            MenuUtils.error(e.getMessage());
        }
        MenuUtils.pausar(sc);
    }

    private void editar() {
        System.out.println("\n--- EDITAR CATEGORÍA ---");
        listarSilenciosa();
        try {
            Long id = MenuUtils.leerLong(sc, "  ID de la categoría a editar: ");
            // Verificar que existe antes de pedir datos
            categoriaService.buscarPorId(id);

            System.out.println("  (Deje vacío para conservar el valor actual)");
            String nuevoNombre = MenuUtils.leerTextoOpcional(sc, "  Nuevo nombre: ");
            String nuevaDesc = MenuUtils.leerTextoOpcional(sc, "  Nueva descripción: ");

            categoriaService.editar(id,
                    nuevoNombre.isBlank() ? null : nuevoNombre,
                    nuevaDesc.isBlank() ? null : nuevaDesc);
            MenuUtils.exito("Categoría actualizada correctamente.");
        } catch (Exception e) {
            MenuUtils.error(e.getMessage());
        }
        MenuUtils.pausar(sc);
    }

    private void eliminar() {
        System.out.println("\n--- ELIMINAR CATEGORÍA (baja lógica) ---");
        listarSilenciosa();
        try {
            Long id = MenuUtils.leerLong(sc, "  ID de la categoría a eliminar: ");
            Categoria c = categoriaService.buscarPorId(id);
            System.out.println("  Categoría seleccionada: " + c);
            if (MenuUtils.leerConfirmacion(sc, "  ¿Confirma la eliminación?")) {
                categoriaService.eliminar(id, productoService.getTodos());
                MenuUtils.exito("Categoría eliminada (baja lógica).");
            } else {
                System.out.println("  Operación cancelada.");
            }
        } catch (Exception e) {
            MenuUtils.error(e.getMessage());
        }
        MenuUtils.pausar(sc);
    }

    /** Lista sin pausar (uso interno previo a editar/eliminar). */
    private void listarSilenciosa() {
        List<Categoria> lista = categoriaService.listar();
        if (!lista.isEmpty()) {
            System.out.println("  Categorías disponibles:");
            lista.forEach(c -> System.out.println("    " + c));
        }
    }
}
