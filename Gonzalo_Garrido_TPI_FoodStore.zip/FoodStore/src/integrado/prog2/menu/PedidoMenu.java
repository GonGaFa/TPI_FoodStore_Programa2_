package integrado.prog2.menu;

import integrado.prog2.entities.DetallePedido;
import integrado.prog2.entities.Pedido;
import integrado.prog2.entities.Producto;
import integrado.prog2.entities.Usuario;
import integrado.prog2.enums.Estado;
import integrado.prog2.enums.FormaPago;
import integrado.prog2.service.PedidoService;
import integrado.prog2.service.ProductoService;
import integrado.prog2.service.UsuarioService;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PedidoMenu {
    private final PedidoService pedidoService;
    private final UsuarioService usuarioService;
    private final ProductoService productoService;
    private final Scanner sc;

    public PedidoMenu(PedidoService pedidoService, UsuarioService usuarioService,
                      ProductoService productoService, Scanner sc) {
        this.pedidoService = pedidoService;
        this.usuarioService = usuarioService;
        this.productoService = productoService;
        this.sc = sc;
    }

    public void mostrar() {
        boolean volver = false;
        while (!volver) {
            System.out.println("\n" + MenuUtils.SEPARADOR);
            System.out.println("       GESTIÓN DE PEDIDOS");
            System.out.println(MenuUtils.SEPARADOR);
            System.out.println("  1. Listar pedidos");
            System.out.println("  2. Listar pedidos por usuario");
            System.out.println("  3. Crear pedido con detalles");
            System.out.println("  4. Actualizar estado / forma de pago");
            System.out.println("  5. Eliminar pedido");
            System.out.println("  0. Volver al menú principal");
            System.out.println(MenuUtils.SEPARADOR_FINO);
            int opcion = MenuUtils.leerIntRango(sc, "  Seleccione: ", 0, 5);

            switch (opcion) {
                case 1 -> listar();
                case 2 -> listarPorUsuario();
                case 3 -> crear();
                case 4 -> actualizarEstado();
                case 5 -> eliminar();
                case 0 -> volver = true;
            }
        }
    }

    private void listar() {
        System.out.println("\n--- LISTADO DE PEDIDOS ---");
        List<Pedido> lista = pedidoService.listar();
        if (lista.isEmpty()) {
            System.out.println("  No hay pedidos registrados.");
        } else {
            for (Pedido p : lista) {
                System.out.println("  " + p);
                for (DetallePedido d : p.getDetalles()) {
                    if (!d.isEliminado()) System.out.println("  " + d);
                }
                System.out.println(MenuUtils.SEPARADOR_FINO);
            }
        }
        MenuUtils.pausar(sc);
    }

    private void listarPorUsuario() {
        System.out.println("\n--- PEDIDOS POR USUARIO ---");
        listarUsuariosSilenciosos();
        try {
            Long idUsr = MenuUtils.leerLong(sc, "  ID del usuario: ");
            Usuario u = usuarioService.buscarPorId(idUsr);
            List<Pedido> lista = pedidoService.listarPorUsuario(u);
            System.out.println("  Pedidos de " + u.getNombre() + " " + u.getApellido() + ":");
            if (lista.isEmpty()) {
                System.out.println("  Sin pedidos.");
            } else {
                for (Pedido p : lista) {
                    System.out.println("  " + p);
                    for (DetallePedido d : p.getDetalles()) {
                        if (!d.isEliminado()) System.out.println("  " + d);
                    }
                }
            }
        } catch (Exception e) {
            MenuUtils.error(e.getMessage());
        }
        MenuUtils.pausar(sc);
    }

    private void crear() {
        System.out.println("\n--- CREAR PEDIDO ---");

        // Seleccionar usuario
        listarUsuariosSilenciosos();
        if (usuarioService.listar().isEmpty()) {
            MenuUtils.error("No hay usuarios registrados. Cree un usuario primero.");
            MenuUtils.pausar(sc);
            return;
        }

        try {
            Long idUsr = MenuUtils.leerLong(sc, "  ID del usuario: ");
            Usuario usuario = usuarioService.buscarPorId(idUsr);

            FormaPago formaPago = seleccionarFormaPago();

            // Seleccionar productos y cantidades
            List<Producto> productosDisponibles = productoService.listar();
            if (productosDisponibles.isEmpty()) {
                MenuUtils.error("No hay productos disponibles. Cargue productos primero.");
                MenuUtils.pausar(sc);
                return;
            }

            List<int[]> items = new ArrayList<>();
            List<Producto> productosSeleccionados = new ArrayList<>();

            boolean agregarMas = true;
            while (agregarMas) {
                System.out.println("\n  Productos disponibles:");
                productosDisponibles.forEach(p -> System.out.println("    " + p));

                Long idProd = MenuUtils.leerLong(sc, "  ID del producto: ");
                Producto prod = productoService.buscarPorId(idProd);
                int cantidad = MenuUtils.leerInt(sc, "  Cantidad: ");

                items.add(new int[]{cantidad});
                productosSeleccionados.add(prod);

                agregarMas = MenuUtils.leerConfirmacion(sc, "  ¿Agregar otro producto?");
            }

            Pedido nuevo = pedidoService.crear(usuario, formaPago, items, productosSeleccionados);
            MenuUtils.exito("Pedido creado con ID: " + nuevo.getId()
                    + " | Total: $" + String.format("%.2f", nuevo.getTotal()));

        } catch (Exception e) {
            MenuUtils.error(e.getMessage());
        }
        MenuUtils.pausar(sc);
    }

    private void actualizarEstado() {
        System.out.println("\n--- ACTUALIZAR PEDIDO ---");
        listarSilenciosa();
        try {
            Long id = MenuUtils.leerLong(sc, "  ID del pedido: ");
            Pedido p = pedidoService.buscarPorId(id);
            System.out.println("  Pedido actual: " + p);

            // Estado opcional
            Estado nuevoEstado = null;
            System.out.println("  Estados: 1=PENDIENTE  2=CONFIRMADO  3=TERMINADO  4=CANCELADO");
            String strEstado = MenuUtils.leerTextoOpcional(sc, "  Nuevo estado (Enter para conservar): ");
            nuevoEstado = switch (strEstado) {
                case "1" -> Estado.PENDIENTE;
                case "2" -> Estado.CONFIRMADO;
                case "3" -> Estado.TERMINADO;
                case "4" -> Estado.CANCELADO;
                default -> null;
            };

            // Forma de pago opcional
            FormaPago nuevaFormaPago = null;
            System.out.println("  Formas de pago: 1=TARJETA  2=TRANSFERENCIA  3=EFECTIVO");
            String strPago = MenuUtils.leerTextoOpcional(sc, "  Nueva forma de pago (Enter para conservar): ");
            nuevaFormaPago = switch (strPago) {
                case "1" -> FormaPago.TARJETA;
                case "2" -> FormaPago.TRANSFERENCIA;
                case "3" -> FormaPago.EFECTIVO;
                default -> null;
            };

            pedidoService.actualizarEstadoYPago(id, nuevoEstado, nuevaFormaPago);
            MenuUtils.exito("Pedido actualizado correctamente.");
        } catch (Exception e) {
            MenuUtils.error(e.getMessage());
        }
        MenuUtils.pausar(sc);
    }

    private void eliminar() {
        System.out.println("\n--- ELIMINAR PEDIDO (baja lógica) ---");
        listarSilenciosa();
        try {
            Long id = MenuUtils.leerLong(sc, "  ID del pedido a eliminar: ");
            Pedido p = pedidoService.buscarPorId(id);
            System.out.println("  Pedido: " + p);
            if (MenuUtils.leerConfirmacion(sc, "  ¿Confirma la eliminación?")) {
                pedidoService.eliminar(id);
                MenuUtils.exito("Pedido eliminado (baja lógica).");
            } else {
                System.out.println("  Operación cancelada.");
            }
        } catch (Exception e) {
            MenuUtils.error(e.getMessage());
        }
        MenuUtils.pausar(sc);
    }

    // ── Helpers ─────────────────────────────────────────────────────────────

    private FormaPago seleccionarFormaPago() {
        System.out.println("  Formas de pago: 1=TARJETA  2=TRANSFERENCIA  3=EFECTIVO");
        int op = MenuUtils.leerIntRango(sc, "  Seleccione: ", 1, 3);
        return switch (op) {
            case 1 -> FormaPago.TARJETA;
            case 2 -> FormaPago.TRANSFERENCIA;
            default -> FormaPago.EFECTIVO;
        };
    }

    private void listarSilenciosa() {
        List<Pedido> lista = pedidoService.listar();
        if (!lista.isEmpty()) {
            System.out.println("  Pedidos registrados:");
            lista.forEach(p -> System.out.println("    " + p));
        }
    }

    private void listarUsuariosSilenciosos() {
        List<integrado.prog2.entities.Usuario> lista = usuarioService.listar();
        if (!lista.isEmpty()) {
            System.out.println("  Usuarios disponibles:");
            lista.forEach(u -> System.out.println("    " + u));
        }
    }
}
