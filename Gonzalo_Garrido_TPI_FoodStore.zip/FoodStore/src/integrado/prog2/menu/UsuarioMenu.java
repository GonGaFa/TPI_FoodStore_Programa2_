package integrado.prog2.menu;

import integrado.prog2.entities.Usuario;
import integrado.prog2.enums.Rol;
import integrado.prog2.service.UsuarioService;

import java.util.List;
import java.util.Scanner;

public class UsuarioMenu {
    private final UsuarioService usuarioService;
    private final Scanner sc;

    public UsuarioMenu(UsuarioService usuarioService, Scanner sc) {
        this.usuarioService = usuarioService;
        this.sc = sc;
    }

    public void mostrar() {
        boolean volver = false;
        while (!volver) {
            System.out.println("\n" + MenuUtils.SEPARADOR);
            System.out.println("       GESTIÓN DE USUARIOS");
            System.out.println(MenuUtils.SEPARADOR);
            System.out.println("  1. Listar usuarios");
            System.out.println("  2. Crear usuario");
            System.out.println("  3. Editar usuario");
            System.out.println("  4. Eliminar usuario");
            System.out.println("  0. Volver al menú principal");
            System.out.println(MenuUtils.SEPARADOR_FINO);
            int opcion = MenuUtils.leerIntRango(sc, "  Seleccione: ", 0, 4);

            switch (opcion) {
                case 1 -> listar();
                case 2 -> crear();
                case 3 -> editar();
                case 4 -> eliminar();
                case 0 -> volver = true;
            }
        }
    }

    private void listar() {
        System.out.println("\n--- LISTADO DE USUARIOS ---");
        List<Usuario> lista = usuarioService.listar();
        if (lista.isEmpty()) {
            System.out.println("  No hay usuarios registrados.");
        } else {
            lista.forEach(u -> System.out.println("  " + u));
        }
        MenuUtils.pausar(sc);
    }

    private void crear() {
        System.out.println("\n--- CREAR USUARIO ---");
        try {
            String nombre = MenuUtils.leerTexto(sc, "  Nombre: ");
            String apellido = MenuUtils.leerTexto(sc, "  Apellido: ");
            String mail = MenuUtils.leerTexto(sc, "  Mail: ");
            String celular = MenuUtils.leerTexto(sc, "  Celular: ");
            String contrasenia = MenuUtils.leerTexto(sc, "  Contraseña: ");
            Rol rol = seleccionarRol();

            Usuario nuevo = usuarioService.crear(nombre, apellido, mail, celular, contrasenia, rol);
            MenuUtils.exito("Usuario creado con ID: " + nuevo.getId());
        } catch (Exception e) {
            MenuUtils.error(e.getMessage());
        }
        MenuUtils.pausar(sc);
    }

    private void editar() {
        System.out.println("\n--- EDITAR USUARIO ---");
        listarSilenciosa();
        try {
            Long id = MenuUtils.leerLong(sc, "  ID del usuario a editar: ");
            Usuario u = usuarioService.buscarPorId(id);
            System.out.println("  Usuario actual: " + u);
            System.out.println("  (Deje vacío para conservar el valor actual)");

            String nuevoNombre = MenuUtils.leerTextoOpcional(sc, "  Nuevo nombre: ");
            String nuevoApellido = MenuUtils.leerTextoOpcional(sc, "  Nuevo apellido: ");
            String nuevoMail = MenuUtils.leerTextoOpcional(sc, "  Nuevo mail: ");
            String nuevoCelular = MenuUtils.leerTextoOpcional(sc, "  Nuevo celular: ");

            // Rol opcional
            Rol nuevoRol = null;
            System.out.println("  Roles disponibles: 1=ADMIN  2=USUARIO  (Enter para conservar)");
            String strRol = MenuUtils.leerTextoOpcional(sc, "  Nuevo rol: ");
            if (strRol.equals("1")) nuevoRol = Rol.ADMIN;
            else if (strRol.equals("2")) nuevoRol = Rol.USUARIO;

            usuarioService.editar(id,
                    nuevoNombre.isBlank() ? null : nuevoNombre,
                    nuevoApellido.isBlank() ? null : nuevoApellido,
                    nuevoMail.isBlank() ? null : nuevoMail,
                    nuevoCelular.isBlank() ? null : nuevoCelular,
                    nuevoRol);
            MenuUtils.exito("Usuario actualizado correctamente.");
        } catch (Exception e) {
            MenuUtils.error(e.getMessage());
        }
        MenuUtils.pausar(sc);
    }

    private void eliminar() {
        System.out.println("\n--- ELIMINAR USUARIO (baja lógica) ---");
        listarSilenciosa();
        try {
            Long id = MenuUtils.leerLong(sc, "  ID del usuario a eliminar: ");
            Usuario u = usuarioService.buscarPorId(id);
            System.out.println("  Usuario: " + u);
            if (MenuUtils.leerConfirmacion(sc, "  ¿Confirma la eliminación?")) {
                usuarioService.eliminar(id);
                MenuUtils.exito("Usuario eliminado (baja lógica).");
            } else {
                System.out.println("  Operación cancelada.");
            }
        } catch (Exception e) {
            MenuUtils.error(e.getMessage());
        }
        MenuUtils.pausar(sc);
    }

    // ── Helpers ─────────────────────────────────────────────────────────────

    private Rol seleccionarRol() {
        System.out.println("  Roles: 1=ADMIN  2=USUARIO");
        int op = MenuUtils.leerIntRango(sc, "  Seleccione rol: ", 1, 2);
        return op == 1 ? Rol.ADMIN : Rol.USUARIO;
    }

    private void listarSilenciosa() {
        List<Usuario> lista = usuarioService.listar();
        if (!lista.isEmpty()) {
            System.out.println("  Usuarios registrados:");
            lista.forEach(u -> System.out.println("    " + u));
        }
    }
}
