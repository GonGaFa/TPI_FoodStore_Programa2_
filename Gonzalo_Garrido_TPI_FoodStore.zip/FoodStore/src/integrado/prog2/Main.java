package integrado.prog2;

import integrado.prog2.menu.CategoriaMenu;
import integrado.prog2.menu.MenuUtils;
import integrado.prog2.menu.PedidoMenu;
import integrado.prog2.menu.ProductoMenu;
import integrado.prog2.menu.UsuarioMenu;
import integrado.prog2.service.CategoriaService;
import integrado.prog2.service.PedidoService;
import integrado.prog2.service.ProductoService;
import integrado.prog2.service.UsuarioService;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        // ── Instancias de servicios (capa de lógica) ──────────────────────
        CategoriaService categoriaService = new CategoriaService();
        ProductoService  productoService  = new ProductoService();
        UsuarioService   usuarioService   = new UsuarioService();
        PedidoService    pedidoService    = new PedidoService();

        Scanner sc = new Scanner(System.in);

        // ── Instancias de menús (capa UI) ─────────────────────────────────
        CategoriaMenu categoriaMenu = new CategoriaMenu(categoriaService, productoService, sc);
        ProductoMenu  productoMenu  = new ProductoMenu(productoService, categoriaService, sc);
        UsuarioMenu   usuarioMenu   = new UsuarioMenu(usuarioService, sc);
        PedidoMenu    pedidoMenu    = new PedidoMenu(pedidoService, usuarioService, productoService, sc);

        // ── Menú principal ────────────────────────────────────────────────
        boolean salir = false;
        while (!salir) {
            System.out.println("\n" + MenuUtils.SEPARADOR);
            System.out.println("    === FOOD STORE – SISTEMA DE PEDIDOS ===");
            System.out.println(MenuUtils.SEPARADOR);
            System.out.println("  1. Categorias");
            System.out.println("  2. Productos");
            System.out.println("  3. Usuarios");
            System.out.println("  4. Pedidos");
            System.out.println("  0. Salir");
            System.out.println(MenuUtils.SEPARADOR_FINO);

            int opcion = MenuUtils.leerIntRango(sc, "  Seleccione: ", 0, 4);

            switch (opcion) {
                case 1 -> categoriaMenu.mostrar();
                case 2 -> productoMenu.mostrar();
                case 3 -> usuarioMenu.mostrar();
                case 4 -> pedidoMenu.mostrar();
                case 0 -> {
                    System.out.println("\n  ¡Hasta luego! Food Store cerrado.\n");
                    salir = true;
                }
            }
        }

        sc.close();
    }
}
